from matplotlib import pyplot as plt
from math import sin
from math import pi
from math import cos

from functions import makelist
from functions import plotlist

plotlist('North hemisphere',makelist('C:\\Users\\ap19062\\SPA4601\\PyCharmProjects\\clay-and-mateusz-project\\A3\\Data.nh'),'slateblue','year','temperature anomalies' )