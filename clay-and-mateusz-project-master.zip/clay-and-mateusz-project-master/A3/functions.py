from matplotlib import pyplot as plt
from math import sin
from math import pi
from math import cos

def makelist(fullPath):
    li = []
    f = open(fullPath, 'r')
    for line in range(0,30):
        fileline = ((f.readline()))
        #z = x.strip('\n')
        splitline = []
        splitline = fileline.split(' ')
        integerssl = int(splitline[0])
        floatssl = float(splitline[1])
        l = (integerssl,floatssl)
        li.append(l)
    return li

def plotlist(plotname, listT, color, xaxis, yaxis):
    x = []
    y = []
    for i in listT:
        x.append(i[0])
        y.append(i[1])
    plt.xlabel(xaxis)
    plt.ylabel(yaxis)
    plt.plot(x,y,color,label=plotname)
    plt.legend()
    plt.savefig('A3part1.png')
    plt.show()
